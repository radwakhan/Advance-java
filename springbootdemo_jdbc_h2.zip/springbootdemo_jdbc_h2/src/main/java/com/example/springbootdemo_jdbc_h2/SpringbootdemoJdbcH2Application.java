package com.example.springbootdemo_jdbc_h2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootdemoJdbcH2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootdemoJdbcH2Application.class, args);
	}

}
